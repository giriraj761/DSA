import client, { fs, MessageMedia, adminCheck } from './modules/clientSetup.mjs';
import robot from 'robotjs';
import JokeAPI from 'sv443-joke-api';
//data
import { menu, classLinks, schedule, appData, additionalData } from './modules/data.mjs';
const { BCGroup, BCTeacher, appAdmin, appBot, } = appData;
const { helloMessage, helloReplies, helloStickers, stickers, promoteStickers, linkFormat } = additionalData;
const savedMedia = {};
let toDoList = [];
let toDoIndex = 0;
// setInterval(() => {
// 	var mouse = robot.getMousePos();
// 	console.log("Mouse is at x:" + mouse.x + " y:" + mouse.y);
// }, 1000);

// recieves a message event
client.on('message', async (msg) => {
	try {

		if (msg.isStatus) {
			console.log('Status recieved.');
			return;
		}
	}
	catch (err) {
		console.log(err);
	}
	let chat;// chat object
	try {
		chat = await msg.getChat();
	} catch (err) {
		console.log(err);
		console.log('Didnt get message');
		return;
	}
	if (chat.isGroup && msg.from === BCGroup) {
		if (msg.author === BCTeacher && msg.links.length > 0 &&
			msg.links[0].link.includes('meet.google.com')) {
			// checks for link update condition
			classLinks.BCM = msg.links[0].link;// change local instance
			// uploads to the fs
			fs.writeFile('./links.json', JSON.stringify(classLinks), (err) => {
				if (err) {
					console.error(err);
				}
			});
		}
		return;
	}// checks if join link is from appAdmin
	if (msg.from === appAdmin && msg.body.startsWith('!join ') && msg.links && msg.links[0].link.includes('chat.whatsapp.com')) {
		const invCode = msg.links[0].link.split('/').pop();
		// trims the code and gets
		try {
			await client.acceptInvite(invCode);
		} catch (err) {
			console.log(err);
		}
		return;
	}
	// if chat is not undefined no error in fetching chat
	// logs all message addressed to the bot
	if (msg.body.startsWith('!')) {
		const num = msg.author ? `${msg.author}` : '';
		// append to local file
		fs.appendFile('./logs.txt', msg.timestamp + ' : ' +
			msg.from + ' : ' + num + ' : ' + msg.body + '\n', (err) => {
				err && console.log('FS invalid:' + err);
			});
	}
	// checks if helloMessage is valide for reply and pings back with sticker
	if (helloMessage.includes(msg.body.toLowerCase())) {
		const media = await MessageMedia.fromFilePath(
			`./stickers/hello${1 + Math.floor(Math.random() * helloStickers)}.jpg`);
		chat.sendMessage(media, { // sticker media
			quotedMessageId: msg.id._serialized, // message to which the reply is
			sendMediaAsSticker: true, // send image as sticker
		});
		// replies from the list randomly
		chat.sendMessage(
			helloReplies[Math.floor(Math.random() * helloReplies.length)]);
	} else if (msg.body === '!joke') {
		// send a joke after fetching from api
		JokeAPI.getJokes() // api call
			.then((res) => res.json())
			.then((data) => {
				if (!data.flags.nsfw && Math.random() > 0.005) {
					// avoids nfsw jokes random chance of fake crash
					if (data.type === 'twopart') {
						msg.reply('*' + data.setup + '*');
						chat.sendMessage(data.delivery);
					} else {
						msg.reply('*' + data.joke + '*');
					}
				} else {
					try {
						const media = MessageMedia.fromFilePath(
							`./stickers/sticker${1 + Math.floor(Math.random() * stickers)}.jpg`,
						);
						chat.sendMessage(media, {
							caption: 'Brain.exe stopped!',
							sendMediaAsSticker: true,
						});
					} catch (err) {
						console.log(err);
					}
				}
			});
	} else if (msg.body === '!help') {
		// prints the help log
		chat.sendMessage(menu.m1 + linkFormat + menu.m2);
	} else if (msg.body.startsWith('!sticker')) {
		// gets the message media and converts it into sticker
		let media = 'Please attach image😅';
		try {
			const mentions = await msg.getMentions();
			// gets mentions {Class Contacts}
			const quotedMsg = await msg.getQuotedMessage();
			// gets quoted message
			if (msg.hasMedia) {// if message has media it is converted to sticker
				if ('image' === msg.type) {
					media = await msg.downloadMedia();// download the media
				} else {
					media = 'Please attach image☹️😓';
				}
			} else if (msg.hasQuotedMsg && quotedMsg.hasMedia) {
				// if quotedMsg has media it is converted to sticker
				if ('image' === quotedMsg.type) {
					try {
						media = await quotedMsg.downloadMedia();
					} catch (err) {
						console.log(err);
						media = 'Something went wrong\nSorry😐😶‍🌫️';
					}
				} else {
					media = 'Quoted file is not image☹️😓';
				}
			} else if (mentions) { // checks if mentions are available
				for (const contact of mentions) {
					try {
						const urlPic = await contact.getProfilePicUrl();
						// gets profile pic of each contact
						media = await MessageMedia.fromUrl(urlPic);
					} catch (err) {
						media = 'contact has\'nt saved my number.😭😭beep boop';
					}
				}
			}
			// sends the media as selected above
			chat.sendMessage(media, {
				sendMediaAsSticker: true,
			});
		} catch (err) {
			console.log(err);
			chat.sendMessage('This file was spammed to often');
		}
	} else if (msg.body.startsWith('!link')) {//sends meet link to the chat
		const content = msg.body.split(' ');
		if (content.length === 1) {
			const today = new Date();// gets current day time
			const hour = today.getHours();
			const day = today.getDay();
			if (hour < 18 && hour > 7 && day < 6) {
				// checks if the time if in the college time
				const cclass = schedule[day][(hour - 8) < 0 ? 0 : hour - 8];
				// fetches classCode from schedule
				msg.reply('```current class```' +
					`(${cclass}) :${classLinks[cclass]}`);
				// sends the link
			} else {
				msg.reply(`${classLinks['NON']}`);
			}
		} else if (content[1] == '-h') {
			// prints the format
			chat.sendMessage(linkFormat);
		} else if (classLinks[content[1].toUpperCase()]) {
			msg.reply(
				'requested link\n' + (content[1].toUpperCase()) + ':' +
				(classLinks[content[1].toUpperCase()]),
			);
		} else {
			chat.sendMessage(linkFormat);
		}
	} else if (msg.hasQuotedMsg && msg.body.startsWith('!save ')) {
		// checks if the messages are attendance sticker and mentions all
		const publicFiles = msg.body.endsWith('-public');
		const name = msg.body.split(' ')[1];
		let status = 'File saved successfully🥳🥳';
		try {
			const quotedMsg = await msg.getQuotedMessage();
			if (quotedMsg.hasMedia) {
				try {
					if (!savedMedia[name]) {
						const media = await quotedMsg.downloadMedia();
						if (!media.mimetype.includes('video/')) {
							savedMedia[name] = {
								'public': publicFiles,
								'media': media,
								'from': msg.from,
							};
						} else {
							status = 'videos/gifs not supported.\nSorry😭😓';
						}
					} else {
						status = 'File name already exists🥲';
					}
					// fs.writeFile('./savedData.json', JSON.stringify(media), err => {
					//   console.log(err + 'error');
					// });
				} catch (err) {
					console.log(err, 'Spammed Here');
					status = 'Something went wrong\nSorry😐😶‍🌫️';
				}
			}
		} catch (err) {
			console.log(err);
		}
		msg.reply(status);
	} else if (msg.body.startsWith('!send ')) {
		// mentions all participants
		const name = msg.body.slice(6);
		let status = 'File sent successfully🥳🥳';
		if (savedMedia[name]) {
			if (
				savedMedia[name].public ||
				msg.from === savedMedia[name].from ||
				msg.from === appAdmin ||
				msg.author === appAdmin) {
				// consition for sending file
				const media = savedMedia[name].media;
				try {
					msg.reply(media);
				} catch (err) {
					status = 'Trouble sending the file.';
					console.log(err);
				}
			} else {
				status = 'its a private file';
			}
		} else {
			status = 'File notfound😓';
		}
		chat.sendMessage(status);
	} else if (msg.body.startsWith('!showfiles')) {
		let savedFiles = '';
		for (const file in savedMedia) {
			if (savedMedia[file]) {
				savedFiles += '*' + file + '*' + ' : ' +
					savedMedia[file].media.mimetype + '\n' +
					'available here : ' +
					(savedMedia[file].from === msg.from).toString() + '\n\n';
			}
		}
		if (savedFiles === '') {
			savedFiles = 'Nothing is saved!😐☹️';
		}
		msg.reply(savedFiles);
	} else if (msg.body.startsWith('!todo ')) {
		const message = msg.body.split(' ');
		if (message[1] === 'add:') {
			toDoList[toDoIndex++] = {
				task: msg.body.slice(msg.body.indexOf(':') + 1),
				user: msg.from
			};
			upDateToDoList();
			msg.reply('Task added.');
		}
		else if (message[1] === 'show') {
			let toSend = '*To Do List*\n';
			let toShow = 0;
			for (let x = 0; x < toDoIndex; x++) {
				if (msg.from === toDoList[x].user) {
					toSend += `${x + 1}: ${toDoList[x].task}`;
					toShow++;
				}
			}
			if (toShow === 0) {
				toSend = '*No task to show*';
			}
			chat.sendMessage(toSend);
		}
		else if (message[1] == 'delete') {
			if (toDoIndex > parseInt(message[2]) - 1 && 0 <= parseInt(message[2]) - 1 && toDoList[parseInt(message[2]) - 1].user === msg.from) {
				toDoList = toDoList.splice(parseInt(message[2] - 1, 1));
				msg.reply('Task removed.');
				upDateToDoList();
			}
			else {
				msg.reply('Invalid index.');
			}
			toDoIndex = toDoList.length;
		}
	} else if ((msg.author === appAdmin || msg.from === appAdmin) && msg.body.startsWith('!delete ')) {
		const name = msg.body.slice(8);
		if (savedMedia[name]) {
			delete savedMedia[name];
			msg.reply(name + ' deleted successfully.😏');
		} else {
			msg.reply(name + ' does not exist.😶‍🌫️');
		}
	} else if (chat.isGroup && msg.body.startsWith('!all')) {
		if (msg.hasQuotedMsg) {// replies to quoted message
			try {
				const quotedMsg = await msg.getQuotedMessage();

				chat.sendMessage('Hi Everyone😁👻,\n please look at this!!', {
					quotedMessageId: quotedMsg.id._serialized.toString(),
					mentions: chat.groupMetadata.participants,
				});
				// robot.typeString('Sorry mic is not working, please mark me present.');
				// robot.keyTap('enter');
			}
			catch (err) {
				console.log('Error');
			}
		} else {// mentions quoting current message
			chat.sendMessage('Hi Everyone😁👻, pay attention!!', {
				quotedMessageId: msg.id._serialized.toString(),
				mentions: chat.groupMetadata.participants,
			});

			// robot.typeString('Sorry mic is not working, please mark me present.');
			// robot.keyTap('enter');
		}
	} else if (chat.isGroup && msg.body.startsWith('!admins')) {
		// mentions all the admins
		const admins = chat.groupMetadata.participants.filter(
			// filters all admins from participants
			(part) => adminCheck(part.author, chat));
		if (msg.hasQuotedMsg) {
			try {
				const quotedMsg = await msg.getQuotedMessage();
				chat.sendMessage('Hi Everyone😁👻,\n please look at this!!', {
					quotedMessageId: quotedMsg.id._serialized.toString(),
					mentions: admins,
				});
			}
			catch (err) {
				console.log(err);
			}
		} else {
			chat.sendMessage('Hi Everyone😁👻, pay attention!!', {
				quotedMessageId: msg.id._serialized.toString(),
				mentions: admins,
			});
		}
	} else if (chat.isGroup && msg.body.startsWith('!promote')) {
		// promotes mentioned user
		if (!adminCheck(msg.author, chat) && msg.author !== appAdmin) {
			// message for non admins
			chat.sendMessage('Sorry, only admins can use this command.😥😭🥲');
		} else if (msg.mentionedIds.length > 0) {
			// promotes mentioned members
			chat.promoteParticipants(msg.mentionedIds);
			const media = await MessageMedia.fromFilePath(
				'./stickers/promote' +
				`${Math.floor(1 + Math.random() * promoteStickers)}.jpg`);
			// selects a random sticker
			chat.sendMessage(media, {
				sendMediaAsSticker: true,
			});
			msg.reply('promoted');
		} else if (!adminCheck(msg.author, chat) && msg.author === appAdmin) {
			// promotes app admin(bypass)
			chat.promoteParticipants([msg.author]);
		}
	} else if (chat.isGroup && msg.body.startsWith('!demote')) {
		if ((!adminCheck(msg.author, chat) && msg.author !== appAdmin) ||
			(msg.mentionedIds.includes(appAdmin) ||
				msg.mentionedIds.includes(appBot))) {
			// message for non admins
			chat.sendMessage('Are you komedy me?.😏🤣😭🥲');
		} else if (msg.mentionedIds.length > 0) {
			// demotes mentioned members
			await chat.demoteParticipants(msg.mentionedIds);
			const media = await MessageMedia.fromFilePath('./stickers/hello1.jpg');
			// selects a random sticker
			chat.sendMessage(media, {
				sendMediaAsSticker: true,
			});
			msg.reply('demoted');
		}
	} else if (chat.isGroup && msg.body.startsWith('!invite ')) {
		// sends group invite link to phone number
		// adminCheck
		if (!adminCheck(msg.author, chat) && msg.author !== appAdmin) {
			chat.sendMessage('Sorry, only admins can use this command.😥😭🥲');
		} else {
			let number = msg.body.split(' ')[1];
			try {
				const message = await chat.getInviteCode();
				// adds formating to number
				number = number.includes('@c.us') ? number : `${number}@c.us`;
				client.sendMessage(
					number.charAt[0] == '+' ? number.split(1) : number,
					`join ${chat.name} link:https://chat.whatsapp.com/${message} 👻`);
				// sends generated link
			} catch (err) {
				chat.sendMessage('Some error occured.😶🥲😭');
			}
		}
	} else if (chat.isGroup && msg.body.startsWith('!reset')) {
		// resets the invitation link
		// adminCheck
		if (!adminCheck(msg.author, chat) && msg.author !== appAdmin) {
			chat.sendMessage('Sorry, only admins can use this command.😥😭🥲');
		} else {
			try {
				await chat.revokeInviteCode();
				chat.sendMessage('Link reset!😎😏');
			} catch (err) {
				chat.sendMessage('Link not reset:' + err);
			}
		}
	} else if (chat.isGroup && msg.body.startsWith('!invitelink')) {
		// sends the invite link to the chat
		// adminCheck
		if (!adminCheck(msg.author, chat) && msg.author !== appAdmin) {
			chat.sendMessage('Sorry, only admins can use this command.😥😭🥲');
		} else {
			try {
				const message = await chat.getInviteCode();
				chat.sendMessage(
					`${chat.name} link:https://chat.whatsapp.com/${message} 👻`);
			} catch (err) {
				chat.sendMessage('Sorry cant do.');
			}
		}
	} else if (chat.isGroup && msg.body.startsWith('!add')) {
		// adds the given phone number to the group
		// adminCheck
		if (!adminCheck(msg.author, chat) && msg.author !== appAdmin) {
			chat.sendMessage('Sorry, only admins can use this command.😥😭🥲');
		} else {
			let number = msg.body.split(' ')[1];
			number = number.includes('@c.us') ? number : `${number}@c.us`;
			try {
				await chat.addParticipants(
					[number.charAt(0) == '+' ? number.slice(1) : number],
				);
			} catch (err) {
				console.error('Error');
			}
		}
	} else if (chat.isGroup && msg.body.startsWith('!remove')) {
		// removes mentioned user
		const number = msg.mentionedIds;
		if ((!adminCheck(msg.author, chat) && msg.author !== appAdmin) ||
			(number.includes(appAdmin) || number.includes(appBot))) {
			chat.sendMessage('Are you komedy me?.😏🤣😭🥲');
		} else {
			if ((number.length < 4 || msg.author === appAdmin)) {
				try {
					await chat.removeParticipants(number);
				} catch (err) {
					chat.sendMessage('I am not an admin');
				}
			} else {
				chat.sendMessage('Will only remove 3 people once.😒😶');
			}
		}
	}
	// else if (msg.body.startsWith('!att')) {
	// 	// removes mentioned user
	// 	robot.keyTap('r', 'command');
	// 	robot.typeString('cmd');
	// 	robot.keyTap('enter');
	// 	robot.typeString('start chrome  https://meet.google.com/xjg-ysyj-yvj');
	// 	robot.keyTap('enter');
	// 	setTimeout(() => {
	// 		console.log('keypressed')
	// 		robot.moveMouse(389, 748);
	// 		robot.mouseClick('left', false);
	// 		robot.keyTap('e', 'control');
	// 		robot.moveMouse(1497, 748);
	// 		robot.mouseClick('left', false);
	// 	}, 5000);

	// }
});
client.initialize();

function upDateToDoList() {
	fs.writeFile('./toDo.json', JSON.stringify(toDoList), err => {
	});
}



//trash
// attendance stickers
// const attendanceStickers = [
//   `WdOV2XZYib5pgC3kf48XzFh8lk55sX746SnaDNq5ja8=`,
//   `GZPPu88y1lSQ2lBO1pMydOzHch3CkLVWEqHeRUzQlOU=`,
// ];