import pkg from 'whatsapp-web.js';
const { Client, MessageMedia } = pkg;
import fs from 'fs';
import qrcode from 'qrcode-terminal';
const SESSION_FILE_PATH = './session.json';
let sessionData = '';

// fetching old saved session
if (fs.existsSync(SESSION_FILE_PATH)) {
    sessionData = JSON.parse(fs.readFileSync(SESSION_FILE_PATH, 'utf8', function (err, data) {
    }));
}
let client;
// starting saved session
if (sessionData !== '') {
    client = new Client({
        session: sessionData,
    });
} else {
    client = new Client();
}
// runs on getting authenticated saves the new session
client.on(`authenticated`, (session) => {
    sessionData = session;
    fs.writeFile(SESSION_FILE_PATH, JSON.stringify(session), (err) => {
        if (err) {
            console.error(err);
        }
    });
});
// generates the qr code for the new session
client.on('qr', (qr) => {
    console.log(`QR RECEIVED ${qr}`);
    qrcode.generate(qr, { small: true });
});
// runs when client connects and is ready
client.on('ready', () => {
    console.log(`Client is ready!`);
});

/**
*this function checks if the sender is an admin or not
*@param {string} author message received
*@param {WAWebJS.Chat} chat chat on which the bot is
*@return {boolean} if the sender is admin
*/
function adminCheck(author, chat) {
    if (!chat.isGroup) {
        return false;
    }
    for (const participant of chat.participants) {
        if (participant.id._serialized === author && !participant.isAdmin) {
            return false;
        }
    }
    return true;
}
export default client;
export { fs, MessageMedia, adminCheck };