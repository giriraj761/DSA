
import fs from 'fs';
let menu, classLinks, schedule, appData
classLinks = getFile(`./links.json`);
menu = getFile(`./menu.json`);
appData = getFile(`./config.json`);
schedule = getFile(`./schedule.json`);
const helloMessage = ['!hey', '!hello', '!hiii'];
const helloReplies = [
    'Hello, 👻👻\nHow are you?',
    'Hoi!👻\nWhat can i do for you.',
    'Hey Bud, Whats up🥳👻',
];
const linkFormat =
    '>``` *Class abbreviation* ```<\n' +
    'AFL  \t|\t COA \t|\t PDC \t|\t BCM\n' +
    'DMT \t|\t OST \t|\t WTT \t|\t :THEORYs\n' +
    'DML \t|\t OSL \t|\t WTL \t|\t :LABs\n';
const helloStickers = 2;
const stickers = 1;
const promoteStickers = 2;
const additionalData = {
    helloMessage,
    helloReplies,
    helloStickers,
    stickers,
    promoteStickers,
    linkFormat
}
function getFile(file) {
    return JSON.parse(fs.readFileSync(file, 'utf8', (err, data) => {
    }));
}
export { menu, classLinks, schedule, appData, additionalData };
