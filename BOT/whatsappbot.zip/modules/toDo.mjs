import fs from 'fs';
let toDoList = {};
function toDoAdd(data) {
};
function toDoDelete() {

};
function toDoShow() {

};
